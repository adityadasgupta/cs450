// test case part 2 for alsonice
// SHORT RUNNING PROC
#include "types.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {
    //long long fact = 1;
    printf(1,"Breaking try2\n");
    exit();
}
